/* Reference only: preserve your existing fault/debug/other peripheral handlers.
 * The four bottom IRQ bodies are the required integration points.
 */
#include "main.h"
#include "typerush_irq.h"
void NMI_Handler(void) { while (1) {} }
void HardFault_Handler(void) { while (1) {} }
void MemManage_Handler(void) { while (1) {} }
void BusFault_Handler(void) { while (1) {} }
void UsageFault_Handler(void) { while (1) {} }
void SVC_Handler(void) {}
void DebugMon_Handler(void) {}
void PendSV_Handler(void) {}
/* Keep HAL on SysTick; do not change HAL timebase to TIM2. */
void SysTick_Handler(void) { HAL_IncTick(); }
void TIM2_IRQHandler(void) { TypeRush_TIM2_IRQHandler(); }
void USART2_IRQHandler(void) { TypeRush_USART2_IRQHandler(); }
void EXTI4_IRQHandler(void) { TypeRush_EXTI4_IRQHandler(); }
void EXTI9_5_IRQHandler(void) { TypeRush_EXTI9_5_IRQHandler(); }
