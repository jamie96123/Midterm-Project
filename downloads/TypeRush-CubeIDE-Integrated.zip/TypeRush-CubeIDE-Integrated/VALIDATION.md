# 本次整合驗證

實際使用交付的 Core/Src/main.c 與 Reference/stm32g4xx_it.c 建置，不是只編譯舊版分檔韌體。

- Arm GNU Toolchain 14.2.1，Cortex-M4F，`-Os -Wall -Wextra -Werror`。
- ST CMSIS-G4 v1.2.5：84d8c1d2e301e873bccd9f4b9a544f1930f66d42。
- Arm CMSIS 5.9.0：2b7495b8535bdcb306dac29b9ded4cfb679d7e5c。
- ST STM32G4 HAL v1.2.5：d69997c6dcdc2d672afae31fee03713fb033c4a8。
- HAL 驗證環境只啟用 RCC / FLASH / PWR / GPIO / CORTEX，使用 SysTick timebase，MSP 啟用 PWR/SYSCFG 時脈。這也確認遊戲不依賴 HAL_UART / HAL_TIM 的回呼或 handle。
- 512KiB Flash 使用 11004 bytes；96KiB 連續 SRAM 使用 5800 bytes（含預留 heap/stack），32KiB CCM 未使用。
- TIM2/USART2/EXTI4/EXTI9_5 四個向量均指向強定義的標準入口，再轉至 TypeRush helper；SysTick_Handler 保留 HAL tick。
- 從交付的單一 main.c 抽取遊戲／協定核心，執行 C 斷言及 8 項 Node 測試全部通過，包含與既有網頁練習引擎的逐步狀態一致性。
- 你原本 SystemClock_Config() 的本文逐字比對相同。

VerifiedBuild/ 提供這個最小匹配驗證環境產生的 HEX / BIN / ELF / MAP，僅供參考；它不是從你尚未提供的完整 CubeIDE 工程產生。實際應以你工程加上四個 IRQ 後重新 Build / Verify 為準。

連結時有 GNU nosys 檔案 I/O stub 與裸機 ELF RWX segment 提示；沒有隱藏這些提示。程式使用記憶體 snprintf、自有 UART ring，不依賴主機檔案 I/O。尚未接實板，不能由編譯或模擬測試推定硬體已正常。

若 Cube 工程的 linker 設定把最小 stack 預留得很小，建議至少 2KiB、可設 4KiB；report() 使用 640-byte 局部緩衝，再加上 snprintf 與中斷保存所需的堆疊。

原始 main.h、it.c、.ioc、HAL conf 與完整工程沒有提供，因此不宣稱已在使用者完整工程中通過 Build。
