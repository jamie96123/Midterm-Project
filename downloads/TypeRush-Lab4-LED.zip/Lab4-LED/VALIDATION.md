# 本版驗證

- 官方 STM32G4 HAL v1.2.5、CMSIS-G4 v1.2.5、Arm CMSIS 5.9.0、Arm GNU 14.2.1 交叉編譯與連結通過，使用實際交付的 main.c。
- Flash 10320 bytes / 512KiB；96KiB 連續 SRAM 使用 3056 bytes（含預留 heap/stack）；32KiB CCM 未使用。
- HEX checksum 正確；LPUART1 向量指向標準 HAL 派送入口，HAL_UART_RxCpltCallback 為本版強定義，SysTick 有保留。
- 主機 C 測試從實際 main.c 擷取 USER CODE 函式，驗證四條指令 count=4/head=tail=34、十批回繞到 84、三燈獨立、CRLF、過長行、255-byte 容量、滿載丟棄與 callback 再啟動接收。
- Chromium / Playwright 5 項全部通過：ACK 後才更新燈態、六條指令及獨立三燈、PPT 四行批次、非法指令及 240-byte 上限、Reset/斷線/重連、手機版面與不支援瀏覽器提示。
- 桌機與手機畫面已檢視。

瀏覽器使用模擬 Web Serial；主機 C 使用 GPIO/HAL 測試替身。沒有接實體板，沒有量測實際 200ms 中斷收發或 LED 電氣層，不能當作實板驗收。你的完整 CubeIDE 工程未提供，因此沒有聲稱已在你的工程 Build。

GNU nosys 連結仍有檔案 I/O stub 和裸機 ELF segment 的標準提示，未隱藏警告。實際傳輸使用 HAL_UART_Transmit，不依賴主機檔案 I/O。

此版和 PPT 的差異僅為指定腳位、補黃燈兩條指令、簡單 OK/ERR 回覆，以及過長行不執行。沒有 JSON、遊戲計分、PWM、Timer 或按鍵中斷。
