#!/usr/bin/env bash
# Linux x86_64 bootstrap. No root access, no global installation, verification stays enabled.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p .deps .tools
fetch_repo() {
  local url="$1" directory="$2" tag="$3" expected="$4"
  if [ ! -e "$directory" ]; then git clone --depth 1 --branch "$tag" "$url" "$directory"; fi
  if [ "$(git -C "$directory" rev-parse HEAD)" != "$expected" ]; then
    echo "Unexpected SDK revision in $directory; preserve local changes and inspect it manually." >&2
    exit 1
  fi
}
fetch_repo https://github.com/STMicroelectronics/cmsis-device-g4.git .deps/cmsis-device-g4 v1.2.5 84d8c1d2e301e873bccd9f4b9a544f1930f66d42
fetch_repo https://github.com/ARM-software/CMSIS_5.git .deps/CMSIS_5 5.9.0 2b7495b8535bdcb306dac29b9ded4cfb679d7e5c
if ! command -v arm-none-eabi-gcc >/dev/null && [ ! -x .tools/arm-gcc/bin/arm-none-eabi-gcc ]; then
  if [ "$(uname -s)-$(uname -m)" != Linux-x86_64 ]; then
    echo 'Install Arm GNU Toolchain (arm-none-eabi-gcc + newlib) for your OS, then rerun.' >&2
    exit 1
  fi
  archive=xpack-arm-none-eabi-gcc-14.2.1-1.1-linux-x64.tar.gz
  url="https://github.com/xpack-dev-tools/arm-none-eabi-gcc-xpack/releases/download/v14.2.1-1.1/$archive"
  curl --fail --location --retry 2 "$url" -o ".tools/$archive"
  # SHA-256 published with this exact xPack release (.tar.gz.sha).
  printf '%s  %s\n' ed8c7d207a85d00da22b90cf80ab3b0b2c7600509afadf6b7149644e9d4790a6 ".tools/$archive" | sha256sum --check -
  mkdir -p .tools/arm-gcc
  tar -xzf ".tools/$archive" --strip-components=1 -C .tools/arm-gcc
  rm ".tools/$archive"
fi
make firmware
