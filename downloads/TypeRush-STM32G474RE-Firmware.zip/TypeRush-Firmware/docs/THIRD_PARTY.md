# Third-party components

Firmware build uses the following external components. SDK code is fetched into ignored `.deps/`, not copied into application source.

- STMicroelectronics CMSIS Device G4 v1.2.5 (`84d8c1d2e301e873bccd9f4b9a544f1930f66d42`): device definitions, startup, SystemInit. [Source](https://github.com/STMicroelectronics/cmsis-device-g4/tree/v1.2.5), [license copy](licenses/ST-CMSIS-G4.md).
- Arm CMSIS 5.9.0 (`2b7495b8535bdcb306dac29b9ded4cfb679d7e5c`): Cortex-M core headers. [Source](https://github.com/ARM-software/CMSIS_5/tree/5.9.0), [license copy](licenses/ARM-CMSIS.txt).
- xPack Arm GNU Toolchain 14.2.1-1.1: cross compiler, binutils, newlib / nano runtime. [Release and distribution notices](https://github.com/xpack-dev-tools/arm-none-eabi-gcc-xpack/releases/tag/v14.2.1-1.1). Toolchain components retain their respective licenses; the bootstrap downloads the full toolchain including its notices. Precompiled firmware links newlib nano and libgcc. Distributed notices: [newlib](licenses/NEWLIB.txt), [libgloss](licenses/LIBGLOSS.txt), [GPLv3](licenses/GCC-GPL3.txt), [GCC Runtime Library Exception](licenses/GCC-RUNTIME-EXCEPTION.txt).
- Playwright 1.58.2 (Apache-2.0): development-only browser testing; not required to serve the static website.

The website has no runtime CDN, webfont, external image or JavaScript dependencies. No slide images are redistributed in the deliverable.
