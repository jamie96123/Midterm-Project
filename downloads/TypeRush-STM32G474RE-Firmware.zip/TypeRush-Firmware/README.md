# TypeRush — STM32G474RE 燒錄專案

這是獨立韌體專案，不包含網頁，也不需要 Node.js / npm。
目標是 NUCLEO-G474RE + 外接共陰極 RGB LED + 四顆按鈕。

## 直接燒錄（不必編譯）

1. 先看 docs/HARDWARE.md 的腳位表接線。
2. 安裝 STM32CubeProgrammer，使用資料 USB 線連到板上 ST-LINK USB。
3. 選 ST-LINK / SWD → Connect。
4. 開啟 **build/typerush.hex**，Download 並 Verify，最後 Reset / Run。
5. 如用 build/typerush.bin，寫入起址為 **0x08000000**。
6. 遊戲網頁的 UART 設定使用 **115200 / 8 / 1 / None / None**。

實體板尚未連接驗收。HEX 已由 Cortex-M4F Arm GNU 工具鏈編譯；
請依 docs/HARDWARE.md 的待測清單確認按鍵、UART、LED 與 PWM。

## 修改並重新建置

Linux x86_64 或 Windows WSL，安裝 Git / curl / tar / sha256sum / make 後：

```sh
./scripts/setup-firmware.sh
make firmware
make test
```

SDK 與編譯器安裝在 .deps/、.tools/；腳本驗證固定 SDK commit 及官方工具鏈 checksum。
其他 OS 可先安裝含 newlib 的 arm-none-eabi-gcc 到 PATH。
亦提供可選 PlatformIO 設定；該途徑本次未完整驗證。

預設 HEX 使用 HSI16 + PLL 170MHz，不依賴外部晶振。
可選 HSE 建置旗標、接線與硬體驗收見 docs/HARDWARE.md。
main.c / board.c / game.c / protocol.c 位於 firmware/src/。
