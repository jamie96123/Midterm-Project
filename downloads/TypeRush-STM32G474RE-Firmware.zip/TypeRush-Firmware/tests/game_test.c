#include "game.h"
#include "protocol.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static void finish_word(Game *g, uint32_t now) {
    char word[WORD_CAP]; strcpy(word, g->word);
    for (size_t i = 0; word[i]; i++) game_key(g, (uint32_t)word[i], now);
}
int main(void) {
    Game g;
    game_init(&g, 0); assert(g.state == READY && g.duration == 8000);
    game_start(&g, 100); assert(g.question == 1 && g.state == RUNNING && g.word[0]);
    game_key(&g, '!', 100); assert(g.wrong == 1 && g.pos == 0 && g.hits == 0);
    finish_word(&g, 100); assert(g.score == 7 && g.correct == 1 && g.question == 2);
    game_start(&g, 0); game_update(&g, 3190); assert(game_tier(&g) == GREEN);
    game_update(&g, 3200); assert(game_tier(&g) == YELLOW);
    finish_word(&g, 3200); assert(g.score == 5);
    game_start(&g, 0); game_update(&g, 5600); assert(game_tier(&g) == YELLOW);
    game_update(&g, 5610); assert(game_tier(&g) == RED);
    finish_word(&g, 5610); assert(g.score == 3);
    game_start(&g, 0); game_pause(&g, 1000); game_update(&g, 100000);
    assert(g.remaining == 7000 && g.elapsed == 1000 && g.state == PAUSED);
    game_key(&g, g.word[0], 100000); assert(g.hits == 0);
    game_resume(&g, 100000); game_update(&g, 101000); assert(g.remaining == 6000);
    game_speed(&g, 101000); assert(g.duration == 5000 && g.remaining == 3750);
    assert(g.elapsed == 2000); game_speed(&g, 101000); assert(g.remaining == 2250);
    game_start(&g, 0); game_update(&g, 30000); assert(g.state == FINISHED && g.misses == 10 && g.elapsed == 30000);
    game_init(&g, 0); game_start(&g, 0); game_update(&g, 80000);
    assert(g.misses == 10 && g.question == 10 && g.state == FINISHED);
    game_start(&g, 0); for (unsigned i = 0; i < 10; i++) finish_word(&g, 0);
    assert(g.state == FINISHED && g.score == 70 && g.correct == 10 && !g.misses);
    game_start(&g, 0); game_update(&g, 6000); game_color(&g); game_color(&g);
    finish_word(&g, 6000); assert(g.score == 3 && !g.manual); /* display cannot cheat */
    game_init(&g, UINT32_MAX - 99u); game_start(&g, UINT32_MAX - 99u);
    game_update(&g, 100); assert(g.elapsed == 200 && g.remaining == 7800);
    game_init(&g, 0);
    assert(game_command(&g,"START",0) == NULL);
    const char *bad[] = {"KEY ","KEY 31","KEY 127","KEY -1","KEY +65","KEY 65x","KEY 65 ","KEY 999999999999999999999"};
    for (unsigned i = 0; i < sizeof(bad)/sizeof(bad[0]); i++) {
        assert(game_command(&g,bad[i],0)); assert(g.attempts == 0);
    }
    assert(game_command(&g,"START extra",0));
    assert(!game_command(&g,"KEY 32",0)); assert(g.attempts == 1);
    assert(!game_command(&g,"PAUSE",10)); assert(g.state == PAUSED);
    assert(!game_command(&g,"RESUME",20)); assert(g.state == RUNNING);
    assert(!game_command(&g,"RESET",30)); assert(g.state == READY && g.attempts == 0);
    puts("C game/protocol assertions passed: scoring boundaries, pause, speed, all rounds, wraparound, strict commands");
    return 0;
}
