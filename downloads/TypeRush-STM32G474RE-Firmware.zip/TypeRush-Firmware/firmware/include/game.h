#ifndef TYPERUSH_GAME_H
#define TYPERUSH_GAME_H
#include <stdint.h>
#define GAME_ROUNDS 10u
#define WORD_CAP 24u
#define WORD_COUNT 40u
typedef enum { READY, RUNNING, PAUSED, FINISHED } GameState;
typedef enum { GREEN, YELLOW, RED, BLUE } LightColor;
typedef struct {
    GameState state;
    uint32_t score, correct, wrong, misses, attempts, hits;
    uint32_t question, remaining, duration, elapsed, last_tick, random;
    uint32_t last_award;
    uint8_t rate, pos, manual;
    LightColor display_color;
    char word[WORD_CAP];
    const char *result;
} Game;
extern const char *const game_words[WORD_COUNT];
void game_init(Game *g, uint32_t now);
void game_start(Game *g, uint32_t now);
void game_update(Game *g, uint32_t now);
void game_pause(Game *g, uint32_t now);
void game_resume(Game *g, uint32_t now);
void game_key(Game *g, uint32_t key, uint32_t now);
void game_speed(Game *g, uint32_t now);
void game_color(Game *g);
LightColor game_tier(const Game *g);
const char *game_state_name(GameState state);
const char *game_color_name(LightColor color);
#endif
