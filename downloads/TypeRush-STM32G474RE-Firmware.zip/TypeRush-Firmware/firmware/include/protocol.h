#ifndef TYPERUSH_PROTOCOL_H
#define TYPERUSH_PROTOCOL_H
#include "game.h"
/* NULL means accepted; a static error code means rejected without executing it. */
const char *game_command(Game *game, const char *line, uint32_t now);
#endif
