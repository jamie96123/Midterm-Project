#ifndef TYPERUSH_BOARD_H
#define TYPERUSH_BOARD_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include "game.h"
void board_init(void);
uint32_t board_millis(void);
uint32_t board_buttons(void);
int board_getchar(void);
bool board_send(const char *data, size_t length);
void board_lights(const Game *g);
uint32_t board_rx_errors(void);
uint32_t board_tx_drops(void);
#endif
