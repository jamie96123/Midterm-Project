#include "board.h"
#include "game.h"
#include "protocol.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static Game game;
static uint32_t protocol_errors;
static void report(void) {
    char frame[640];
    int n = snprintf(frame, sizeof(frame),
        "{\"t\":\"state\",\"v\":1,\"state\":\"%s\",\"word\":\"%s\",\"pos\":%lu,"
        "\"score\":%lu,\"correct\":%lu,\"wrong\":%lu,\"misses\":%lu,\"attempts\":%lu,\"hits\":%lu,"
        "\"question\":%lu,\"total\":10,\"remaining\":%lu,\"duration\":%lu,\"elapsed\":%lu,"
        "\"rate\":%lu,\"color\":\"%s\",\"manual\":%lu,\"lastAward\":%lu,\"result\":\"%s\","
        "\"rxErrors\":%lu,\"txDrops\":%lu,\"protocolErrors\":%lu}\n",
        game_state_name(game.state), game.word, (unsigned long)game.pos,
        (unsigned long)game.score, (unsigned long)game.correct, (unsigned long)game.wrong,
        (unsigned long)game.misses, (unsigned long)game.attempts, (unsigned long)game.hits,
        (unsigned long)game.question, (unsigned long)game.remaining, (unsigned long)game.duration,
        (unsigned long)game.elapsed, (unsigned long)game.rate, game_color_name(game.display_color),
        (unsigned long)game.manual, (unsigned long)game.last_award, game.result,
        (unsigned long)board_rx_errors(), (unsigned long)board_tx_drops(), (unsigned long)protocol_errors);
    if (n > 0 && (size_t)n < sizeof(frame)) board_send(frame, (size_t)n);
}
static void error(const char *code) {
    char frame[100];
    protocol_errors++;
    int n = snprintf(frame, sizeof(frame), "{\"t\":\"error\",\"code\":\"%s\"}\n", code);
    if (n > 0 && (size_t)n < sizeof(frame)) board_send(frame, (size_t)n);
}
static void command(const char *line, uint32_t now) {
    const char *code = game_command(&game, line, now);
    if (code) { error(code); return; }
    report();
}
int main(void) {
    board_init();
    game_init(&game, board_millis());
    report();
    char line[64];
    size_t length = 0;
    bool discard = false;
    uint32_t last_report = board_millis(), last_lights = UINT32_MAX;
    for (;;) {
        uint32_t now = board_millis();
        GameState previous = game.state;
        uint32_t old_question = game.question;
        game_update(&game, now);
        uint32_t pending = board_buttons();
        if (pending & 1u) {
            if (game.state == PAUSED) game_resume(&game, now);
            else if (game.state != RUNNING) game_start(&game, now);
        }
        if (pending & 2u) {
            if (game.state == PAUSED) game_resume(&game, now);
            else game_pause(&game, now);
        }
        if (pending & 4u) game_color(&game);
        if (pending & 8u) game_speed(&game, now);
        int c;
        /* Bound work per iteration so a busy sender cannot starve countdown/light updates. */
        for (unsigned budget = 0; budget < 128u; budget++) {
            c = board_getchar();
            if (c == -1) break;
            if (c == -2) { length = 0; discard = true; continue; }
            if (c == '\r') continue;
            if (c == '\n') {
                if (discard) { error("RX_FRAME_DROPPED"); }
                else if (length) { line[length] = 0; command(line, board_millis()); }
                length = 0; discard = false;
            } else if (!discard) {
                if (c < 32 || c > 126 || length >= sizeof(line) - 1u) {
                    discard = true; length = 0;
                } else line[length++] = (char)c;
            }
        }
        if (now != last_lights) { board_lights(&game); last_lights = now; }
        if (pending || previous != game.state || old_question != game.question
            || (uint32_t)(now - last_report) >= 100u) {
            report(); last_report = now;
        }
        /* IRQ may occur just before WFI; next 10ms timer IRQ bounds sleep latency. */
        __asm volatile ("wfi");
    }
}
