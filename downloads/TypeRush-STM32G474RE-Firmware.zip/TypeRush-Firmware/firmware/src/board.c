#include "stm32g4xx.h"
#include "board.h"
/* RX and TX use separate single-producer/single-consumer rings. */
#define RX_CAP 512u
#define TX_CAP 2048u
static volatile uint8_t rx[RX_CAP], tx[TX_CAP];
static volatile uint16_t rx_head, rx_tail, tx_head, tx_tail;
static volatile uint32_t ticks, buttons, rx_errors, tx_drops;
static volatile bool rx_discard;
static uint32_t button_times[4];
static const uint32_t breath_periods[] = {1800, 1200, 700};
/* Default is crystal-independent HSI. Optional external HSE must be 8/16/24 MHz.
 * For an externally driven MCO clock, set TYPERUSH_HSE_BYPASS=1.
 * A missing selected HSE intentionally stops startup; reset and flash the HSI build.
 */
#ifndef TYPERUSH_HSE_HZ
#define TYPERUSH_HSE_HZ 0
#endif
#ifndef TYPERUSH_HSE_BYPASS
#define TYPERUSH_HSE_BYPASS 0
#endif
#if TYPERUSH_HSE_HZ != 0 && TYPERUSH_HSE_HZ != 8000000 && TYPERUSH_HSE_HZ != 16000000 && TYPERUSH_HSE_HZ != 24000000
#error "Supported HSE inputs: 8, 16 or 24 MHz (PLL input must be 4 MHz)"
#endif
static void clock_init(void) {
    RCC->APB1ENR1 |= RCC_APB1ENR1_PWREN;
    (void)RCC->APB1ENR1;
    PWR->CR1 = (PWR->CR1 & ~PWR_CR1_VOS) | PWR_CR1_VOS_0;
    PWR->CR5 &= ~PWR_CR5_R1MODE; /* Range 1 boost: required above 150 MHz */
    while (PWR->SR2 & PWR_SR2_VOSF) {}
    RCC->CR |= RCC_CR_HSION;
    while (!(RCC->CR & RCC_CR_HSIRDY)) {}
#if TYPERUSH_HSE_HZ
#if TYPERUSH_HSE_BYPASS
    RCC->CR |= RCC_CR_HSEBYP;
#endif
    RCC->CR |= RCC_CR_HSEON;
    while (!(RCC->CR & RCC_CR_HSERDY)) {}
    /* HSE / (HSE_HZ / 4MHz) * 85 / 2 = 170 MHz. */
    RCC->PLLCFGR = RCC_PLLCFGR_PLLSRC_HSE
                 | ((TYPERUSH_HSE_HZ / 4000000u - 1u) << RCC_PLLCFGR_PLLM_Pos)
                 | (85u << RCC_PLLCFGR_PLLN_Pos) | RCC_PLLCFGR_PLLREN;
#else
    /* HSI16 / 4 * 85 / 2 = 170 MHz, APB1/APB2 = AHB = SYSCLK. */
    RCC->PLLCFGR = RCC_PLLCFGR_PLLSRC_HSI | (3u << RCC_PLLCFGR_PLLM_Pos)
                 | (85u << RCC_PLLCFGR_PLLN_Pos) | RCC_PLLCFGR_PLLREN;
#endif
    FLASH->ACR = FLASH_ACR_LATENCY_4WS | FLASH_ACR_PRFTEN | FLASH_ACR_ICEN | FLASH_ACR_DCEN;
    while ((FLASH->ACR & FLASH_ACR_LATENCY) != FLASH_ACR_LATENCY_4WS) {}
    RCC->CR |= RCC_CR_PLLON;
    while (!(RCC->CR & RCC_CR_PLLRDY)) {}
    /* Use an intermediate AHB divide-by-2 while ramping up from 16 MHz. */
    RCC->CFGR = (RCC->CFGR & ~(RCC_CFGR_SW | RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2))
              | RCC_CFGR_SW_PLL | RCC_CFGR_HPRE_DIV2;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL) {}
    for (volatile unsigned settle = 0; settle < 170u; settle++) __NOP();
    RCC->CFGR &= ~RCC_CFGR_HPRE;
    __DSB();
    SystemCoreClock = 170000000u;
}
static void mode(GPIO_TypeDef *port, unsigned pin, unsigned value) {
    port->MODER = (port->MODER & ~(3u << (pin * 2u))) | (value << (pin * 2u));
}
static void alternate(GPIO_TypeDef *port, unsigned pin, unsigned af) {
    unsigned reg = pin / 8u, shift = (pin % 8u) * 4u;
    port->AFR[reg] = (port->AFR[reg] & ~(15u << shift)) | (af << shift);
    mode(port, pin, 2);
}
static void gpio_init(void) {
    RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN | RCC_AHB2ENR_GPIOBEN;
    RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;
    (void)RCC->AHB2ENR;
    mode(GPIOA, 5, 1); /* Nucleo LD2: direct output */
    GPIOA->BSRR = 1u << (5u + 16u);
    for (unsigned pin = 4; pin <= 7; pin++) {
        mode(GPIOB, pin, 0);
        GPIOB->PUPDR = (GPIOB->PUPDR & ~(3u << (pin * 2u))) | (1u << (pin * 2u));
        unsigned reg = pin / 4u, shift = (pin % 4u) * 4u;
        SYSCFG->EXTICR[reg] = (SYSCFG->EXTICR[reg] & ~(15u << shift)) | (1u << shift);
    }
    EXTI->RTSR1 &= ~(15u << 4);
    EXTI->FTSR1 |= 15u << 4; /* external normally-open switches to GND */
    EXTI->PR1 = 15u << 4;
    EXTI->IMR1 |= 15u << 4;
    NVIC_SetPriority(EXTI4_IRQn, 2);
    NVIC_SetPriority(EXTI9_5_IRQn, 2);
    NVIC_EnableIRQ(EXTI4_IRQn);
    NVIC_EnableIRQ(EXTI9_5_IRQn);
}
static void uart_init(void) {
    alternate(GPIOA, 2, 7);
    alternate(GPIOA, 3, 7);
    RCC->APB1ENR1 |= RCC_APB1ENR1_USART2EN;
    (void)RCC->APB1ENR1;
    USART2->CR1 = 0;
    USART2->BRR = 1476; /* 170 MHz / 115200, OVER8=0, 8 data, no parity, 1 stop */
    USART2->CR2 = 0;
    USART2->CR3 = USART_CR3_EIE;
    USART2->ICR = USART_ICR_ORECF | USART_ICR_FECF | USART_ICR_NECF | USART_ICR_PECF;
    USART2->CR1 = USART_CR1_UE | USART_CR1_RE | USART_CR1_TE | USART_CR1_RXNEIE;
    NVIC_SetPriority(USART2_IRQn, 1);
    NVIC_EnableIRQ(USART2_IRQn);
}
static void timers_init(void) {
    RCC->APB1ENR1 |= RCC_APB1ENR1_TIM2EN | RCC_APB1ENR1_TIM3EN;
    (void)RCC->APB1ENR1;
    TIM2->PSC = 169;
    TIM2->ARR = 9999; /* 170MHz/170/10000 = 100Hz = 10ms */
    TIM2->EGR = TIM_EGR_UG;
    TIM2->SR = 0;
    TIM2->DIER = TIM_DIER_UIE;
    NVIC_SetPriority(TIM2_IRQn, 0);
    NVIC_EnableIRQ(TIM2_IRQn);
    TIM2->CR1 = TIM_CR1_CEN;
    alternate(GPIOA, 6, 2); /* TIM3_CH1, red */
    alternate(GPIOA, 7, 2); /* TIM3_CH2, green */
    alternate(GPIOB, 0, 2); /* TIM3_CH3, blue */
    TIM3->PSC = 169;
    TIM3->ARR = 999; /* 1kHz hardware PWM carrier */
    TIM3->CCMR1 = (6u << TIM_CCMR1_OC1M_Pos) | TIM_CCMR1_OC1PE
                | (6u << TIM_CCMR1_OC2M_Pos) | TIM_CCMR1_OC2PE;
    TIM3->CCMR2 = (6u << TIM_CCMR2_OC3M_Pos) | TIM_CCMR2_OC3PE;
    TIM3->CCER = TIM_CCER_CC1E | TIM_CCER_CC2E | TIM_CCER_CC3E;
    TIM3->CCR1 = TIM3->CCR2 = TIM3->CCR3 = 0;
    TIM3->EGR = TIM_EGR_UG;
    TIM3->CR1 = TIM_CR1_ARPE | TIM_CR1_CEN;
}
void board_init(void) { clock_init(); gpio_init(); uart_init(); timers_init(); }
uint32_t board_millis(void) { return ticks; }
void TIM2_IRQHandler(void) {
    if (TIM2->SR & TIM_SR_UIF) { TIM2->SR = 0; ticks += 10u; }
}
static void button_irq(unsigned index) {
    unsigned pin = index + 4u;
    if (EXTI->PR1 & (1u << pin)) {
        EXTI->PR1 = 1u << pin; /* write one to clear */
        if (!(GPIOB->IDR & (1u << pin)) && (uint32_t)(ticks - button_times[index]) >= 50u) {
            button_times[index] = ticks;
            buttons |= 1u << index;
        }
    }
}
void EXTI4_IRQHandler(void) { button_irq(0); }
void EXTI9_5_IRQHandler(void) { button_irq(1); button_irq(2); button_irq(3); }
uint32_t board_buttons(void) {
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    uint32_t pending = buttons;
    buttons = 0;
    __set_PRIMASK(primask);
    return pending;
}
void USART2_IRQHandler(void) {
    uint32_t status = USART2->ISR;
    if (status & (USART_ISR_ORE | USART_ISR_FE | USART_ISR_NE | USART_ISR_PE)) {
        USART2->ICR = USART_ICR_ORECF | USART_ICR_FECF | USART_ICR_NECF | USART_ICR_PECF;
        rx_errors++;
        rx_discard = true;
    }
    if (status & USART_ISR_RXNE) {
        uint8_t c = (uint8_t)USART2->RDR;
        if (rx_discard) {
            if (c == '\n') {
                /* Drop queued fragments as well; no malformed command may execute. */
                rx_head = rx_tail;
                rx_discard = false;
                uint16_t next = (uint16_t)((rx_head + 1u) % RX_CAP);
                rx[rx_head] = '\n';
                __DMB(); rx_head = next;
            }
        } else {
            uint16_t next = (uint16_t)((rx_head + 1u) % RX_CAP);
            if (next == rx_tail) { rx_errors++; rx_discard = true; }
            else { rx[rx_head] = c; __DMB(); rx_head = next; }
        }
    }
    if ((status & USART_ISR_TXE) && (USART2->CR1 & USART_CR1_TXEIE)) {
        if (tx_tail != tx_head) {
            USART2->TDR = tx[tx_tail];
            tx_tail = (uint16_t)((tx_tail + 1u) % TX_CAP);
        } else USART2->CR1 &= ~USART_CR1_TXEIE;
    }
}
int board_getchar(void) {
    /* A very short critical section also serializes error recovery with the ISR. */
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    static uint32_t notified_errors;
    int c = -1;
    if (notified_errors != rx_errors) {
        notified_errors = rx_errors;
        c = -2; /* main loop must discard its partial command through next newline */
    } else if (rx_tail != rx_head) {
        c = rx[rx_tail];
        rx_tail = (uint16_t)((rx_tail + 1u) % RX_CAP);
    }
    __set_PRIMASK(primask);
    return c;
}
bool board_send(const char *data, size_t length) {
    uint16_t head = tx_head;
    size_t free_bytes = (tx_tail + TX_CAP - head - 1u) % TX_CAP;
    if (length > free_bytes) { tx_drops++; return false; }
    for (size_t i = 0; i < length; i++) {
        tx[head] = (uint8_t)data[i]; head = (uint16_t)((head + 1u) % TX_CAP);
    }
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    __DMB(); tx_head = head;
    USART2->CR1 |= USART_CR1_TXEIE;
    __set_PRIMASK(primask);
    return true;
}
void board_lights(const Game *g) {
    uint32_t brightness = 600;
    if (g->state == RUNNING) {
        uint32_t period = breath_periods[g->rate];
        uint32_t phase = g->elapsed % period;
        uint32_t triangle = phase < period / 2u ? phase : period - phase;
        brightness = 80u + triangle * 900u / (period / 2u);
    } else if (g->state == READY) brightness = 160;
    if (g->state == PAUSED) {
        /* Actual MODER+BSRR GPIO output, not just a constant PWM duty. */
        mode(GPIOA, 6, 1); mode(GPIOA, 7, 1); mode(GPIOB, 0, 1);
        bool red = g->display_color == RED || g->display_color == YELLOW;
        bool green = g->display_color == GREEN || g->display_color == YELLOW;
        GPIOA->BSRR = (red ? 1u << 6 : 1u << 22) | (green ? 1u << 7 : 1u << 23);
        GPIOB->BSRR = g->display_color == BLUE ? 1u : 1u << 16;
    } else {
        TIM3->CCR1 = (g->display_color == RED || g->display_color == YELLOW) ? brightness : 0;
        TIM3->CCR2 = (g->display_color == GREEN || g->display_color == YELLOW) ? brightness : 0;
        TIM3->CCR3 = g->display_color == BLUE ? brightness : 0;
        alternate(GPIOA, 6, 2); alternate(GPIOA, 7, 2); alternate(GPIOB, 0, 2);
    }
    GPIOA->BSRR = g->state == RUNNING && ((ticks / 500u) & 1u) ? 1u << 5 : 1u << 21;
}
uint32_t board_rx_errors(void) { return rx_errors; }
uint32_t board_tx_drops(void) { return tx_drops; }
