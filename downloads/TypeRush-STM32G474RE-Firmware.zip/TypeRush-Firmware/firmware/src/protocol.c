#include "protocol.h"
#include <stdlib.h>
#include <string.h>
const char *game_command(Game *game, const char *line, uint32_t now) {
    if (!strcmp(line, "SYNC")) game_update(game, now);
    else if (!strcmp(line, "START")) game_start(game, now);
    else if (!strcmp(line, "PAUSE")) game_pause(game, now);
    else if (!strcmp(line, "RESUME")) game_resume(game, now);
    else if (!strcmp(line, "RESET")) game_init(game, now);
    else if (!strcmp(line, "COLOR")) { game_update(game, now); game_color(game); }
    else if (!strcmp(line, "SPEED")) game_speed(game, now);
    else if (!strncmp(line, "KEY ", 4)) {
        char *end;
        unsigned long key = strtoul(line + 4, &end, 10);
        if (line[4] < '0' || line[4] > '9' || *end || key < 32 || key > 126) return "INVALID_KEY";
        game_key(game, (uint32_t)key, now);
    } else return "UNKNOWN_COMMAND";
    return NULL;
}
