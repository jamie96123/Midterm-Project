#include "game.h"
#include <string.h>
const char *const game_words[WORD_COUNT] = {
    "rhythm", "light", "timer", "signal", "board", "focus", "pulse", "typing",
    "clock", "green", "yellow", "speed", "serial", "buffer", "button", "score",
    "bright", "flow", "micro", "pixel", "logic", "react", "power", "flash",
    "input", "output", "energy", "swift", "challenge", "breathe", "spark", "wave",
    "orbit", "shift", "dream", "coding", "tempo", "motion", "switch", "level"
};
static const uint32_t durations[] = {8000, 5000, 3000};
static void next_word(Game *g) {
    g->question++;
    if (g->question > GAME_ROUNDS) {
        g->question = GAME_ROUNDS;
        g->state = FINISHED;
        g->remaining = 0;
        return;
    }
    g->random = g->random * 1664525u + 1013904223u;
    strcpy(g->word, game_words[(g->random >> 16) % WORD_COUNT]);
    g->duration = durations[g->rate];
    g->remaining = g->duration;
    g->pos = 0;
    g->manual = 0;
}
void game_init(Game *g, uint32_t now) {
    memset(g, 0, sizeof(*g));
    g->state = READY;
    g->duration = durations[0];
    g->remaining = g->duration;
    g->last_tick = now;
    g->random = 0x474;
    g->display_color = BLUE;
    g->result = "ready";
}
void game_start(Game *g, uint32_t now) {
    uint8_t rate = g->rate;
    uint32_t seed = g->random ^ now;
    game_init(g, now);
    g->rate = rate;
    g->random = seed;
    g->state = RUNNING;
    g->result = "started";
    next_word(g);
    g->display_color = game_tier(g);
}
LightColor game_tier(const Game *g) {
    if (g->remaining * 100u > g->duration * 60u) return GREEN;
    if (g->remaining * 100u >= g->duration * 30u) return YELLOW;
    return RED;
}
void game_update(Game *g, uint32_t now) {
    uint32_t delta = now - g->last_tick; /* unsigned subtraction handles tick wrap */
    g->last_tick = now;
    while (g->state == RUNNING && delta) {
        uint32_t spent = delta < g->remaining ? delta : g->remaining;
        g->remaining -= spent;
        g->elapsed += spent;
        delta -= spent;
        if (!g->remaining) {
            g->misses++;
            g->last_award = 0;
            g->result = "timeout";
            next_word(g);
        }
    }
    if (!g->manual && (g->state == RUNNING || g->state == PAUSED))
        g->display_color = game_tier(g);
}
void game_pause(Game *g, uint32_t now) {
    game_update(g, now);
    if (g->state == RUNNING) { g->state = PAUSED; g->result = "paused"; }
}
void game_resume(Game *g, uint32_t now) {
    game_update(g, now);
    if (g->state == PAUSED) { g->state = RUNNING; g->result = "resumed"; }
}
void game_key(Game *g, uint32_t key, uint32_t now) {
    game_update(g, now);
    if (g->state != RUNNING) return;
    /* Backspace deliberately does not erase accepted progress or accuracy history. */
    if (key < 32 || key > 126) return;
    g->attempts++;
    if (key == (uint8_t)g->word[g->pos]) {
        g->hits++;
        g->pos++;
        g->result = "hit";
        if (!g->word[g->pos]) {
            LightColor tier = game_tier(g);
            g->last_award = tier == GREEN ? 7u : tier == YELLOW ? 5u : 3u;
            g->score += g->last_award;
            g->correct++;
            g->result = "correct";
            next_word(g);
        }
    } else { g->wrong++; g->result = "wrong"; }
    game_update(g, now);
}
void game_speed(Game *g, uint32_t now) {
    game_update(g, now);
    g->rate = (uint8_t)((g->rate + 1u) % 3u);
    /* A changed difficulty starts with the same remaining fraction, never a free refill. */
    uint32_t duration = durations[g->rate];
    g->remaining = (g->remaining * duration + g->duration - 1u) / g->duration;
    g->duration = duration;
    g->result = "speed";
    game_update(g, now);
}
void game_color(Game *g) {
    g->display_color = g->display_color == BLUE ? GREEN : (LightColor)((g->display_color + 1u) % 3u);
    g->manual = 1;
    g->result = "color"; /* presentation override; score always uses the real time tier */
}
const char *game_state_name(GameState state) {
    static const char *const names[] = {"ready", "running", "paused", "finished"};
    return names[state];
}
const char *game_color_name(LightColor color) {
    static const char *const names[] = {"green", "yellow", "red", "blue"};
    return names[color];
}
